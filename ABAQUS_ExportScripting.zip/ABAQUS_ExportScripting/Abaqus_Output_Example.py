# ========================= Initiations and importing libraries =========================
from abaqus import *
from abaqusConstants import *
# Adjusting viewport width and height
session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=340, 
    height=260)
session.viewports['Viewport: 1'].makeCurrent()
session.viewports['Viewport: 1'].maximize()
from caeModules import *
from driverUtils import executeOnCaeStartup
session.journalOptions.setValues(replayGeometry=COORDINATE, recoverGeometry=COORDINATE)


# ========================= Select a folder for all files ===============================
img_Folder='Exported_Images/'
anim_Folder='Exported_Animations/'
txt_Folder='Exported_Texts/'


# ========================= Setting up ODB file to extract information from =============
o1 = session.openOdb(name='C:/temp/Job-1.odb')
# Assign view point to the ODB 
session.viewports['Viewport: 1'].setValues(displayedObject=o1)



# ========================= Save SMises Image ===========================================
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_DEF, ))
session.viewports['Viewport: 1'].odbDisplay.setValues(viewCut=ON)
session.viewports['Viewport: 1'].view.setValues(session.views['Right'])
session.viewports['Viewport: 1'].odbDisplay.commonOptions.setValues(
    visibleEdges=FEATURE)
session.printOptions.setValues(vpDecorations=OFF, reduceColors=False)
session.printToFile(fileName=img_Folder+'Image_SMises', format=TIFF, canvasObjects=(
    session.viewports['Viewport: 1'], ))


# ========================= Save PEEQ Image =============================================
session.viewports['Viewport: 1'].odbDisplay.setPrimaryVariable(
    variableLabel='PEEQ', outputPosition=INTEGRATION_POINT, )
session.printOptions.setValues(vpDecorations=OFF, reduceColors=False)
session.printToFile(fileName=img_Folder+'Image_PEEQ', format=TIFF, canvasObjects=(
    session.viewports['Viewport: 1'], ))



# ========================= PEEQ-Mises from a List of Elements ==========================
El_List=[7560, 1144, 1800, 6904, 248, 1454]
for el_num in El_List:
	session.xyDataListFromField(odb=o1, outputPosition=ELEMENT_CENTROID, 
	    variable=(('PEEQ', INTEGRATION_POINT), ('S', INTEGRATION_POINT, ((
	    INVARIANT, 'Mises'), )), ), elementLabels=(('SPECIMEN-1', (
	    str(el_num), )), ), )
	xy1 = session.xyDataObjects['PEEQ PI: SPECIMEN-1 E: '+str(el_num)+' Centroid']
	xy2 = session.xyDataObjects['S:Mises PI: SPECIMEN-1 E: '+str(el_num)+' Centroid']
	xy3 = combine(xy1, xy2)
	xy3.setValues(
	    sourceDescription='combine ( "PEEQ PI: SPECIMEN-1 E: '+str(el_num)+' Centroid", "S:Mises PI: SPECIMEN-1 E: '+str(el_num)+' Centroid" )')
	tmpName = xy3.name
	session.xyDataObjects.changeKey(tmpName, 'XYData-'+str(el_num))
	xyp = session.XYPlot('XYPlot-'+str(el_num))
	chartName = xyp.charts.keys()[0]
	chart = xyp.charts[chartName]
	xy1 = session.xyDataObjects['XYData-'+str(el_num)]
	c1 = session.Curve(xyData=xy1)
	chart.setValues(curvesToPlot=(c1, ), )
	session.viewports['Viewport: 1'].setValues(displayedObject=xyp)
	session.printToFile(fileName=img_Folder+'PEEQ_SMises_'+str(el_num), format=TIFF, canvasObjects=(
	    session.viewports['Viewport: 1'], ))



# ========================= PEEQ-Mises Data into text files =============================
for el_num in El_List:
	session.xyDataListFromField(odb=o1, outputPosition=ELEMENT_CENTROID, 
	    variable=(('PEEQ', INTEGRATION_POINT), ('S', INTEGRATION_POINT, ((
	    INVARIANT, 'Mises'), )), ), elementLabels=(('SPECIMEN-1', (
	    str(el_num), )), ), )
	xy1 = session.xyDataObjects['PEEQ PI: SPECIMEN-1 E: '+str(el_num)+' Centroid']
	xy2 = session.xyDataObjects['S:Mises PI: SPECIMEN-1 E: '+str(el_num)+' Centroid']
	# Export to a Text file
	session.writeXYReport(fileName=txt_Folder+'PEEQ-Mises'+str(el_num)+'.txt', appendMode=OFF, xyData=(xy1, 
	    xy2))



# ========================= Save Mises and S11, S22, S33 Animation ======================
S_List=['Mises','S11', 'S22', 'S33']
for s_name in S_List:
	aux = COMPONENT
	if s_name == 'Mises':
		aux = INVARIANT
	#
	session.viewports['Viewport: 1'].setValues(displayedObject=o1)
	session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
	    UNDEFORMED, ))
	session.viewports['Viewport: 1'].view.setValues(session.views['Right'])
	session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
	    CONTOURS_ON_DEF, ))
	session.viewports['Viewport: 1'].odbDisplay.setPrimaryVariable(
	    variableLabel='S', outputPosition=INTEGRATION_POINT, refinement=(aux, 
	    s_name), )
	session.animationController.setValues(animationType=TIME_HISTORY, viewports=(
	    'Viewport: 1', ))
	session.animationController.play(duration=UNLIMITED)
	session.viewports['Viewport: 1'].odbDisplay.commonOptions.setValues(
	    visibleEdges=FEATURE)
	#: AVI Codec set to:Microsoft Video 1
	session.aviOptions.setValues(
	    codecOptions='[16]:enfdfgedbiaaaaaaaeaaaaaaelaaaaaa', 
	    compressionQuality=100)
	session.imageAnimationOptions.setValues(vpDecorations=ON, vpBackground=OFF, 
	    compass=OFF, timeScale=1, frameRate=5)
	session.writeImageAnimation(fileName=anim_Folder+'Animation_'+s_name, format=AVI, 
	    canvasObjects=(session.viewports['Viewport: 1'], ))
	session.animationController.setValues(animationType=NONE)



# ========================= Save PEEQ Animation =========================================
session.viewports['Viewport: 1'].odbDisplay.setPrimaryVariable(
    variableLabel='PEEQ', outputPosition=INTEGRATION_POINT, )
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    UNDEFORMED, ))
session.viewports['Viewport: 1'].view.setValues(session.views['Right'])
session.viewports['Viewport: 1'].odbDisplay.display.setValues(plotState=(
    CONTOURS_ON_DEF, ))
session.animationController.setValues(animationType=TIME_HISTORY, viewports=(
    'Viewport: 1', ))
session.animationController.play(duration=UNLIMITED)
session.viewports['Viewport: 1'].odbDisplay.commonOptions.setValues(
    visibleEdges=FEATURE)
#: AVI Codec set to:Microsoft Video 1
session.aviOptions.setValues(
    codecOptions='[16]:enfdfgedbiaaaaaaaeaaaaaaelaaaaaa', 
    compressionQuality=100)
session.imageAnimationOptions.setValues(vpDecorations=ON, vpBackground=OFF, 
    compass=OFF, timeScale=1, frameRate=5)
session.writeImageAnimation(fileName=anim_Folder+'Animation_PEEQ', format=AVI, 
    canvasObjects=(session.viewports['Viewport: 1'], ))
session.animationController.setValues(animationType=NONE)


